#include "FibHeap.hpp"
#include "FibNode.hpp"
#include <cmath>
#include <algorithm>
#include "testFibList.hpp"
#define BASE 1.6

using namespace std; 
	FibHeap::FibHeap( const vector<double>&v ):
		dis( v )
	{
		int n = dis.size();
		size = n;
		
		mapped = vector<FibNode*>( n, NULL );
		
		for( int i = 0; i < n; ++i )
		{
			mapped[ i ] = new FibNode( i );
		}
		
//		cout << 1 << endl;
		auto it = min_element( dis.begin(), dis.end( ) );
		
		min = mapped[ it - dis.begin() ];
		min->left = min->right = min;
		
//		cout << 2 << endl;
		
		for( int i = 0; i < n; ++i )
		{
//			cout << "i " << i << endl;
			
			if( mapped[ i ] != min )
			{
				fibListAdd( min, mapped[ i ] );
			}
		}
		
//		printFibHeap( min );
	}
	
	FibHeap::~FibHeap( )
	{
		for( int i = 0; i < mapped.size( ); ++i )
		{
			delete mapped[ i ];
		}
	}
	
	void FibHeap::decreaseKey( int u )
	{
		FibNode *x = mapped[ u ];
		
		FibNode *y = x->parent;
		
		if( y != NULL && less( x->key, y->key ) )
		{
			cut( x, y );
			cascadingCut( y );
		}
		
		if( greater( min->key, x->key ) )
		{
			min = x;
		}
		
//		printFibHeap( min );
	}
	
	int FibHeap::extractMin( )
	{
		int u = min->key;
		
		vector<FibNode*> all = allFibNodes( min->child );
		
//		cout << 1 << endl;
		for( int i = 0; i < all.size( ); ++i )
		{
			fibListAdd( min, all[ i ] );
		}
		
//		cout << 2 << endl;
		if( min->left == min )
		{
			min = NULL;
		}
		else
		{
			min = min->left;
			fibListDelete( min->right );
//			cout << 3 << endl;
			consoliadate( );
		}
		
//		cout << 4 << endl;
//		printFibHeap( min );
		--size;
		return u;
	}

//	FibNode *min;
//	int size;
//	
//	const vector<int> &dis; 
//	vector<FibNode *> mapped;
	
	bool FibHeap::greater( int u, int v ) const
	{
		return dis[ u ] > dis[ v ];
	}
	bool FibHeap::less( int u, int v) const
	{
		return dis[ u ] < dis[ v ];
	}
	
	void FibHeap::consoliadate( )
	{
		vector<FibNode *> A( ( int )( log( size ) / log( BASE )) + 3, NULL );
		
		vector<FibNode *> all = allFibNodes( min );
		
		for( int i = 0; i < all.size( ); ++i )
		{
			FibNode* x = all[ i ];
			int d = x->degree; 
			
			while( A[ d ] != NULL )
			{
				FibNode *y = A[ d ];
				
				if( less( y->key, x->key ) )
				{
					swap( x, y );
				}
				
				fibHeapLink( y, x );
				
				A[ d ] = NULL;
				++d;
			}
			
			A[ d ] = x;
			x->degree = d;
		}
		
		min = NULL;
		for( int i = 0; i < A.size( ); ++i )
		{
			if( A[ i ] != NULL )
			{
				fibListAdd( min, A[ i ] );
				
				if( greater( min->key, A[ i ]->key ) )
				{
					min = A[ i ];	
				}
			}
		}
	}
	
	void FibHeap::fibHeapLink( FibNode *y, FibNode *x )
	{
		fibListDelete( y );
		fibListAdd( x->child, y, x );
		
		++x->degree;
		
		y->mark = false;
	}
	void FibHeap::cut( FibNode *x, FibNode *y )
	{
		fibListDelete( x );
		
		fibListAdd( min, x );
		
		--y->degree;
		
		if( y->degree == 0 )
		{
			y->child = NULL;
		}
		
		x->mark = false;
	}
	void FibHeap::cascadingCut( FibNode *y )
	{
		FibNode *z = y->parent;
		
		if( z != NULL )
		{
			if( y->mark == false )
			{
				y->mark = true;	
			}	
			else
			{
				cut( y, z );
				
				cascadingCut( z );
			}
		} 
	}
	
	

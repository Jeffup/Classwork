#include "testFibList.hpp"
#include <vector>
#include <iostream>

using namespace std;
void testListOperation( )
{
	//����ͷ 
	FibNode *p = new FibNode( 2 );
	
	p->left = p;
	p->right = p;
	vector< FibNode *> arr( 10, 0 );
	
	//����10��node 
	for( int i = 0; i < 10; ++i )
	{
		arr[ i ] = new FibNode( i );
	}
	
	int n, num ;
	
	cin >> n;
	num = n;
	
	cout << n << " addition " << endl;
	while( n-- )
	{
		int a;
		
		cin >> a;
		
		fibListAdd( p, arr[ a ] );
		
//		cout << 2 <<endl;
		printList( p );
	}
	
	n = num - 1;
	//ɾ�� 
	cout << n << " deletion " << endl;
	while( n-- )
	{
		int a;
		
		cin >> a;
		fibListDelete( arr[ a ] );
		
		printList( p );
	}
	
	n = num + 2;
	cout << n  << " addtion to child " << endl;
	while( n-- )
	{
		int a;
		
		cin >> a;
		
		fibListAdd( p->child, arr[ a ], p );
		
//		cout << 1 << endl;
		printFibHeap( p );
	}
}

void printFibHeap( const FibNode *p, int num)
{
	if( p == NULL )
	{
		return;
	}
	
	const FibNode *temp = p;
	
	do
	{
		cout << "level " << num << " " << temp->key << " ";
		printFibHeap( temp->child, num + 1 );
		
		if( num == 0 )
		{
			cout << endl;
		}
		temp = temp->left;
	}while(  temp != p  );
}
void printList( const FibNode *p )
{
	if( p == NULL )
	{
		return;
	}
	
	const FibNode *temp = p;
	
	do
	{
		cout << temp->key << " ";
		
		temp = temp->left;
	}while( temp != p );
	
	cout << endl;
}

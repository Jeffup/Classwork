#ifndef FIBHEAPHPP
#define FIBHEAPHPP

#include <vector>
#include "FibNode.hpp"
using namespace std;

struct FibFibNode:public FibNode
{
		bool mark;
	   int degree;
	
	   FibFibNode *parent;
	   FibFibNode *child;
	   
	   FibFibNode( int key, FibFibNode *child = NULL, FibFibNode *parent = NULL, FibNode *left = NULL, FibNode *right = NULL, bool mark = false, int degree = 0  );
};

class FibHeap
{
public:
	FibHeap( const vector<double>&v );
	void decreaseKey( int u );
	int extractMin( );
	~FibHeap( );
private:
	FibNode *min;
	int size;
	
	const vector<double> &dis; //�Զ�������d������ 
	vector<FibNode *> mapped;//�Ӷ��㵽쳲�������Ԫ�ص�ӳ�� 
	bool greater( int u, int v ) const;//�ȽϹؼ��� 
	bool less( int u, int v) const;//�ȽϹؼ���
	 
	void consoliadate( );
	void fibHeapLink( FibNode *y, FibNode *x );
	void cut( FibNode *x, FibNode *y );
	void cascadingCut( FibNode *y );
	void deleteFibList( FibNode * x );
};

#endif

#include <iostream>
#include <vector>
#include "ShortestPath.hpp"
#include "mkGraph.hpp" 
#include "test.hpp"
#include "testFibList.hpp"
#include "testFibHeap.hpp"
using namespace std;

int main( )
{
	testRealOptimize( );
	return 0;
}

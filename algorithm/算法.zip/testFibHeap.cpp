#define N 10
#include "FibHeap.hpp"
#include <vector>

using namespace std;
void creation( )
{
	vector<double> v( N, 0 );
	
	for( int i = 0; i < N; ++i )
	{
		v[ i ] = i;
	}
	
	FibHeap f( v ); 
	for( int i = 0; i < 3; ++i )
	{
		int u = f.extractMin();
		
		cout << "u " << u << endl;
	}
	
	for( int i = 0; i < 3; ++i )
	{
		v[ i + 5 ] = 3 - i;
		
		f.decreaseKey( i + 5 );
		cout << endl;
	}
}

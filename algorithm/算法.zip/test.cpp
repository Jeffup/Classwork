#include <iostream>
#include <vector>
#include "ShortestPath.hpp"
#include "mkGraph.hpp" 
#include "test.hpp"
#include <cstdlib>
#include <algorithm>  
#include <ctime>
#include <cstdio>
using namespace std;

Graph mkGraph( )
{
	int m, n;
	
	cout << "�����붥�������ͱߵ�����" << endl;
	cin >> n >> m;
	
	Graph g( n, vector<Edge>( ) );
	while( m-- )
	{
		cout << "������ߵ������˵��Ȩ��" << endl; 
		int a, b, w;
		
		cin >> a >> b >> w;
		
		g[ a ].push_back( Edge( b, w, 1 ) );
		g[ b ].push_back( Edge( a, w, 1 ) );
	}
	
	return g;
}

vector< vector<int > >  mkLine( )
{
	int m, n;
	
	cin >> n >> m;
	
	vector< vector<int> > res( n, vector<int>( ) );
	
	while( m-- )
	{
		int num, k;
		
		cin >> num >> k;
		
		while( k-- )
		{
			int l;
			
			cin >> l;
			
			res[ num ].push_back( l );
		}
	}
	
	return res;
}

void testMKLine( )
{
  
	vector< vector<int> > res = mkLine( );
	
	Graph g = mkLineGragh( res, 10 );
	
	for( int i = 0; i <  g.size( ); ++i )
	{
		cout << "i " << i << endl;
		
		for( int j = 0; j < g[ i ].size( ); ++j )
		{
			cout << g[ i ][ j ].end << " " << g[ i ][ j ].satellite << " ";
		}
		
		cout << endl;
	}
}

Distance singleDataTestDijkstra( const Graph& g, const string &str, bool output )
{
	int choice = 1;
	if( str == "array" )
	{
		choice = 1;
	}
	else if( str == "fibHeap" )
	{
		choice = 3;
	} 
	else
	{
		choice = 2;
	}
	
	clock_t start = clock( );
	pair<Distance, PreNode> both = shortestPath( g, choice );
	clock_t end = clock( );
	
	if( output )
		printf( "%s used time: %f\n", str.c_str( ), ( double )(end-start)/CLOCKS_PER_SEC );
	
	return both.first;	
} 

bool testThreeDataOneTime( int n, int m, bool output )
{
	Distance arr[ 3 ];
	
	if( output )
	{
		cout << "vertex " << n << " edge " << m << endl; 
	}
	
	Graph g = mkRandomGraph( n, m );
	arr[ 0 ] = singleDataTestDijkstra( g, "array", output );
	arr[ 1 ] =  singleDataTestDijkstra( g, "binaryHeap", output );
	arr[ 2 ] =  singleDataTestDijkstra( g, "fibHeap", output );
	
	return arr[ 0 ] == arr[ 1 ] && arr[ 2 ] == arr[ 0 ] && arr[ 1 ] == arr[ 2 ]; 
}

void printDistance( Distance dis, const string &str )
{
	cout << str << " test " << endl;
	cout << "distance array " << endl;
	for( int i = 0; i < dis.size( ); ++i )
	{
		for( int j = 0; j < dis.size(); ++j )
		{
			cout << dis[ i ][ j ] << " ";
		}
	 
		cout << endl;
	}
}
void testDijkstra( int choice )
{
//	cout << "nm " << endl;
	Graph g = mkGraph( );
	
//	cout << "te1 " << endl;
	pair<Distance, PreNode> both = shortestPath( g, choice );
	
//	cout << "te2 "  << endl;
	Distance dis = both.first;
	PreNode pre = both.second; 
	
	cout << "distance array " << endl;
	for( int i = 0; i < dis.size( ); ++i )
	{
		for( int j = 0; j < dis.size(); ++j )
		{
			cout << dis[ i ][ j ] << " ";
		}
	 
		cout << endl;
	}
}


Graph mkRandomGraph( int n, int m )
{
	Graph g( n, vector<Edge>( ) );
	
	//��������ͼ 
	vector<int> v( n, 0);
	for( int i = 0; i < n; ++i )
	{
		v[ i ] = i;
	}
	random_shuffle( v.begin( ), v.end( ) ); 
	
	for( int i = 0; i < n - 1; ++i )
	{
		int a = v[ i ], b = v[ i + 1 ];
		
		g[ a ].push_back( Edge( b, rand( ) % 100, 1 ) );
		g[ b ].push_back( Edge( a, rand( ) % 100, 1 )  );
//		cout << "a " << a << " b " << b << endl; 
	}
	
	for( int i = n ; i < m; ++i )
	{
		int a = 1, b = 1;
		
		while( a == b )
		{
			a =  rand( ) % n , b =  rand( ) % n ;
		}
		
		g[ a ].push_back( Edge( b, rand( ) % 100, 1 ) );
		g[ b ].push_back( Edge( a, rand( ) % 100, 1 )  );
	}
	
	return g;
}

void testTimeComplexity( )
{
	for( int i = 100; i < 500000; i += 500  )
	{
		int n = i, m = i + rand( ) % ( i * i - i );
		
		if( !testThreeDataOneTime( n, m, true ) )
		{
			cout << "ERROR" << endl;
			return;
		}
			
		cout << endl;
		
	}
}

void testRealOptimize( )
{
	for( int n = 100; n < 5000; n += 100 )
	{
			if( !testThreeDataOneTime( n, n * ( rand() % 20 + 1 ), true ) )
			{
				cout << "ERROR" << endl;
				return;
			}
			
			cout << endl;
	}
}

void testRealOptimize2( )
{
	for( int n = 100; n < 5000; n += 500 )
	{
			if( !testThreeDataOneTime( n, n * n - 2 * n - rand( ) % ( 10 * n) , true ) )
			{
				cout << "ERROR" << endl;
				return;
			}
			
			cout << endl;
	}
}

void testDijkstraThree( )
{
	Graph g = mkGraph( ); 
	
	Distance arr[ 3 ];
	
	arr[ 0 ] = singleDataTestDijkstra( g, "array", false );
	printDistance( arr[ 0 ], "array" );

	arr[ 1 ] =  singleDataTestDijkstra( g, "binaryHeap", false );
   printDistance( arr[ 1 ], "binaryHeap" );
   
	arr[ 2 ] =  singleDataTestDijkstra( g, "fibHeap", false );
	printDistance( arr[ 2 ], "fibHeap" );
} 

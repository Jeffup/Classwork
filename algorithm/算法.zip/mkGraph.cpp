#include "mkGraph.hpp"
#include <iostream>

using namespace std;
// ��������v��v���±��ʾstation��v[i]��ʾ��վi���ڵ�����·�ߣ�lineNum��ʾ��·���� 
Graph mkLineGragh( const vector< vector<int> >& v, int lineNum )
{
	Graph g = constructGraph( lineNum + 1 );
	
	for( int i = 0; i < v.size( ); ++i )
	{
		cout << v[ i ].size( ) << endl;
		vector< vector<int> > res = combine2( v[ i ] );
		
		if( res.empty( ) )
		{
			continue;
		}
		
		for( int j = 0; j < res.size(); ++j )
		{
			int a = res[ j ][ 0 ], b =res[ j ][ 1 ];
			
			g[ a ].push_back( Edge( b, 1, i ) );
			g[ b ].push_back( Edge( a, 1, i ) );
		}	
	} 
	
	return g;
}

Graph constructGraph( int size )
{
	return vector< vector< Edge > > ( size, vector<Edge>  ( ) );
}

vector< vector<int> > combine2( const vector<int>& v)
{
	vector< vector<int> > res;
	if( v.size( ) <= 1 )
	{
		return res;
		}	
	vector<int> temp = v;
	
	cout << temp.size( ) << endl;
	 
	for( int i = 0; i < temp.size( ) - 1; ++i )
	{
		for( int j = i + 1; j < temp.size( ); ++j )
		{
			vector<int> t( 2, 0 );		
	
			t[ 0 ] = temp[ i ];
			t[ 1 ] = temp[ j ];
			res.push_back( t );	
		}	
	} 
	
	return res;
} 
